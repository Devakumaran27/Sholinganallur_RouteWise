ROUTEWISE AI — SHOLINGANALLUR ONLY DATASET

Extracted from the previously reviewed Chennai MTC 16-area GTFS-derived dataset.
Source upload: static_mtc_gtfs_data(3).zip
Source archive: static_mtc_gtfs_data/chennai.bus.gtfs.zip

RECORD COUNTS
- Bus stop records: 26
- Route service summary records: 278
- Unique route IDs in route summary: 278
- Unique route numbers: 58
- Unique trips serving matched stops: 5285
- Scheduled stop departure records: 18439
- Direct scheduled T. Nagar connections from Sholinganallur: 170

FILES
- bus_stops.csv
- route_service_summary.csv
- scheduled_departures.csv
- direct_t_nagar_connections.csv
- area_summary.json
- routewise_sholinganallur_dataset.json

IMPORTANT
The area filter uses area_id = sholinganallur. The direct-connection filter uses
origin_area_id = sholinganallur. The source locality matching and coordinate
quality flags are preserved; locality boundaries are not independently verified.
GTFS schedule values are static feed values, not live bus tracking.
